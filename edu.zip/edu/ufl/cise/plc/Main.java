package edu.ufl.cise.plc;

public class Main {
    public static void main(String[] args){

        float value = Float.parseFloat("1.19872398471248971204123047910932471231234124314323242");
        int intVal = Integer.parseInt("9999999999");
        System.out.print(intVal );

    }
}
