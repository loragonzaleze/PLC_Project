package edu.ufl.cise.plc.ast;

import edu.ufl.cise.plc.IToken;

public abstract class Expr extends ASTNode{

	public Expr(IToken firstToken) {
		super(firstToken);
	}
	
}
